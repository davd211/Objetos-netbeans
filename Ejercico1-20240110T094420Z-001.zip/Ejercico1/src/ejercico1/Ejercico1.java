/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercico1;

import java.util.Scanner;

/**
 *
 * @author alumno
 */
public class Ejercico1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
  Scanner tec = new Scanner(System.in);

        Coche coche1 = new Coche ();
        char a;
        int b;

        a = tec.nextLine().charAt(0);
        b = tec.nextInt();
        

        switch (a) {
            case 'A':
                coche1.acelera(b);
                break;

            case 'F':
                coche1.frena(b);
                break;
            default:
                throw new AssertionError();
        }
        
        System.out.println("La velocidad actual es: "+coche1.getVelocidad()+" KM/H");

    }

    }
    

