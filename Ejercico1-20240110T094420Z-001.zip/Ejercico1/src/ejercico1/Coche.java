/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercico1;

/**
 *
 * @author alumno
 */
public class Coche {
     

    private int velocidad;

    Coche() {

        velocidad = 0;
    }

    int getVelocidad() {
        return this.velocidad;
    }

    void acelera(int mas) {
        this.velocidad = this.velocidad + mas;
    }

    void frena(int menos) {
        this.velocidad = this.velocidad + menos;
    }

}


    

